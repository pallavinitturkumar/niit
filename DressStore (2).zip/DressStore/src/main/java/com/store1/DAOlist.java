package com.store1;
import java.util.*;


public class DAOlist {

	
	public List<product> dataList()
	{
		product p= new product(001,"red color",300.0,"Dress");
		product p1= new product(002,"green",200.0,"Dress");
		product p2= new product(003,"red",100.0,"Dress");
		ArrayList al=new ArrayList();
		al.add(p);
		al.add(p1);
		al.add(p2);
		return al;
		
	}
	
}
