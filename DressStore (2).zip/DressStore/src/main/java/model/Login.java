package model;

public class Login {
	String uname;
	String password;
	
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public boolean isValidLogin()
	{ 
		if(uname.equals("")&&password.equals(""))
			return true;
		else
			return false;
	}
}
