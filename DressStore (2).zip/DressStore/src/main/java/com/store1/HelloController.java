package com.store1;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class HelloController {
	
	String message="welcome to the Dress Store!";
	private object userDAO;
	@RequestMapping("/")
	public String showIndex(){
		return "Homepage";
	}
	@RequestMapping("/Homepage")
	public String showHome(){
		return "Homepage";
	}
	@RequestMapping("/Signup")
	public String showSignup(){
		return "Signup";

	}
	@RequestMapping("/productTable")
	public String showProd()
	{
		return "productTable";
	}
	@RequestMapping("/Login")
	public String showLogin(){
		return "Login";
	}
	@RequestMapping(value="/productTable",method=RequestMethod.GET)
	public ModelAndView prodTable()
	{
		DAOlist dil = new DAOlist();
		ModelAndView mav = new ModelAndView("productTable");
		mav.addObject("dl",dil.dataList());
		return mav;
	}
	@RequestMapping("/Signup")
	public String registerCustomer(Model model){
		Customer customer=new Customer();
		ModelAndView mav = new ModelAndView("Customer");
		mav.addObject("cl",customer.dataList());
		return mav;
	}

}

