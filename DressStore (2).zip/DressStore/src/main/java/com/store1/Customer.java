package com.store1;
import com.fasterxml.jackson.annotation.JsonIgnore;
import org.springframework.web.bind.annotation.RequestMapping;


@Entity
public class Customer implements Seralizable{
	private static final long serialVersionUID=5140900014886997914L;
	
	@Id
	@GeneratedValue
	private int customerId;
	@NotEmpty(message="the customer name must not be null.")
	private String customerName;
	
	@NotEmpty(message="the customer Email and phone number must not be null.")
	private String customerPhonenumber;
	private String customerEmailadress;
	
	@NotEmpty(message="the customer username cant be null.")
	private String username;
	@NotEmpty(message="the customer password cant be null.")
	private String password;
	
	private boolean enabled;
	
	@OneToOne
	@JoinColumn(name="billingAddressId")
	private BillingAddress billingAddress;
	
	@OneToOne
	@JoinColumn(name="shippingAddressId")
	private ShippingAddress shippingAddress;
	
	@OneToOne
	@JoinColumn(name="cartId")
	@JsonIgnore
	private Cart cart;

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerPhonenumber() {
		return customerPhonenumber;
	}

	public void setCustomerPhonenumber(String customerPhonenumber) {
		this.customerPhonenumber = customerPhonenumber;
	}

	public String getCustomerEmailadress() {
		return customerEmailadress;
	}

	public void setCustomerEmailadress(String customerEmailadress) {
		this.customerEmailadress = customerEmailadress;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	
}
